package lucene;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class LuceneIndexer {
    private static final String INDEX_DIRECTORY = "C:\\temp\\indexluc";

    private static List<Document> readCsvFile(String filename) throws IOException {
        List<Document> documents = new ArrayList<Document>();
        BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            if (values.length >= 3) { // check that the array has at least three elements
                Document document = new Document();
                document.add(new TextField("artist", values[0], Field.Store.YES));
                document.add(new TextField("song", values[1], Field.Store.YES));
                document.add(new TextField("text", values[2], Field.Store.YES));
                documents.add(document);
            }
        }
        br.close();
        return documents;
    }

    public static List<Document> searchIndex(IndexSearcher searcher, String query, String field) throws Exception, ParseException {
        QueryParser parser = new QueryParser(field, new StandardAnalyzer());
        Query luceneQuery = parser.parse(query);
        TopDocs topDocs = searcher.search(luceneQuery, 10);
        ScoreDoc[] hits = topDocs.scoreDocs;

        List<Document> results = new ArrayList<Document>();
        for (ScoreDoc hit : hits) {
            Document doc = searcher.doc(hit.doc);
            results.add(doc);
        }

        return results;
    }

    public static void main(String[] args) throws Exception {
        Analyzer analyzer = new StandardAnalyzer();
        Path path = FileSystems.getDefault().getPath(INDEX_DIRECTORY);
        Directory directory = FSDirectory.open(path);

        // Create the index by indexing the documents
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter writer = new IndexWriter(directory, config);
        List<Document> documents = readCsvFile("C:\\Users\\panad\\Desktop\\AnakthshFinal\\spotify_millsongdata.csv");
        writer.addDocuments(documents);
        writer.close();

        // Search the index for a given query
        IndexSearcher searcher = new IndexSearcher(DirectoryReader.open(directory));
        String query = "some query string";
        List<Document> results = searchIndex(searcher, query, "give specific field");
        for (Document doc : results) {
            System.out.println(doc.get("filename"));
        }
    }
}
