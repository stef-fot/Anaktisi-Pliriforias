package lucene;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//public class SearchHistoryItem {
//    private String query;
//    private String titleQuery;
//    private String artistQuery;
//    private boolean titleSelected;
//    private boolean artistSelected;
//    private Date timestamp;
//    private List<String> alternativeQueries;
//
//    public SearchHistoryItem(String query, String titleQuery, String artistQuery, boolean titleSelected, boolean artistSelected) {
//        this.query = query;
//        this.titleQuery = titleQuery;
//        this.artistQuery = artistQuery;
//        this.titleSelected = titleSelected;
//        this.artistSelected = artistSelected;
//        this.timestamp = new Date();
//        this.alternativeQueries = new ArrayList<>();
//    }
//
//    public String getQuery() {
//        return query;
//    }
//
//    public Date getTimestamp() {
//        return timestamp;
//    }
//
//    public void addAlternativeQuery(String query) {
//    	alternativeQueries.add(query);
//    }
//
//    public String getSuggestion(String query) {
//        String suggestion = null;
//        int maxOverlap = 0;
//        for (String altQuery : alternativeQueries) {
//            int overlap = getOverlap(query, altQuery);
//            if (overlap > maxOverlap) {
//                suggestion = altQuery;
//                maxOverlap = overlap;
//            }
//        }
//        return suggestion;
//    }
//
//    private int getOverlap(String s1, String s2) {
//        String[] words1 = s1.split("\\s+");
//        String[] words2 = s2.split("\\s+");
//        int overlap = 0;
//        for (String word1 : words1) {
//            for (String word2 : words2) {
//                if (word1.equalsIgnoreCase(word2)) {
//                    overlap++;
//                }
//            }
//        }
//        return overlap;
//    }
//}

//import java.time.LocalDateTime;
//
//public class SearchHistoryItem {
//    private final String query;
//    private final boolean titleSearch;
//    private final boolean artistSearch;
//    private final LocalDateTime timestamp;
//    private SearchHistoryItem searchHistory;
//
//    public SearchHistoryItem(String query, boolean titleSearch, boolean artistSearch) {
//        this.query = query;
//        this.titleSearch = titleSearch;
//        this.artistSearch = artistSearch;
//        this.timestamp = LocalDateTime.now();
//       
//    }
//
//    public String getQuery() {
//        return query;
//    }
//
//    public boolean isTitleSearch() {
//        return titleSearch;
//    }
//
//    public boolean isArtistSearch() {
//        return artistSearch;
//    }
//
//    public LocalDateTime getTimestamp() {
//        return timestamp;
//    }
//    
//
//}
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

public class SearchHistoryItem {
    
    private static Map<String, Integer> history = new HashMap<>();
    private static ArrayList<String> searchHistory = new ArrayList<String>();

    
    public static void addToHistory(String query) {
        try {
            // Open the search history file in append mode
            File file = new File("C:/temp/indexluc/search_history.txt");
            FileWriter writer = new FileWriter(file, true);
            
            // Write the query to the file and add it to the search history list
            writer.write(query + "\n");
            searchHistory.add(query);
            
            // Close the file writer
            writer.close();
        } catch (IOException e) {
            System.err.println("Error writing to search history file: " + e.getMessage());
        }
    }

    
    public static List<String> getRecommendations() {
        List<String> recommendations = new ArrayList<>();
        for (String searchTerm : history.keySet()) {
            if (history.get(searchTerm) >= 3) {
                recommendations.add("Have you tried searching for " + searchTerm + "?");
            }
        }
        return recommendations;
    }
    
    public static void main(String[] args) {
        String searchTerm = JOptionPane.showInputDialog("What would you like to search for?");
        addToHistory(searchTerm);
        List<String> recommendations = getRecommendations();
        if (!recommendations.isEmpty()) {
            String message = "Based on your search history, we recommend:\n";
            for (String recommendation : recommendations) {
                message += recommendation + "\n";
            }
            JOptionPane.showMessageDialog(null, message);
        }
    }
}

