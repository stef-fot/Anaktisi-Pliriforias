package lucene;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
//import java.awt.List;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.standard.*;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.*;
import org.apache.lucene.search.*;
import org.apache.lucene.store.*;
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.util.List;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TopDocs;
//import org.apache.lucene.search.uhighlight.UnifiedHighlighter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

//import org.deeplearning4j.models.embeddings.loader.WordVectorSerializer;
//import org.deeplearning4j.models.embeddings.wordvectors.WordVectors;

//import org.nd4j.linalg.api.ndarray.INDArray;
//import org.nd4j.linalg.factory.Nd4j;
//import org.nd4j.linalg.ops.transforms.Transforms;

public class LuceneIndexerGUI extends JFrame implements ActionListener {
    private static final String INDEX_DIRECTORY = "C:\\temp\\indexluc";
    private static final String[] FIELD_NAMES = {"artist", "song", "text"};

    private JLabel queryLabel;
    private JTextField queryField;
    private JCheckBox titleCheckbox;
    private JCheckBox artistCheckbox;
    private JButton searchButton;
    private JButton moreButton; //button more
    private JTextArea resultArea;
    private JTextArea historyArea;



    private Analyzer analyzer;//needed for the highlighted
    private Directory directory;
    private IndexSearcher searcher;//needed for the highlighted

    private int currentPage = 0;
    private int totalPages = 0;

    private int more_counter_display=0;//////gia to more sto display.ADDED!
    private int firstsearch=0; //gia to pack.ADDED!

    private String myquery;//myQuery for the highlighted format
    private JTextComponent textComponent;//to text gia to song
    private JPanel topPanel; //the panel

    private ArrayList<String> searchHistory;
    private String queryString;

	private TopDocs currentResults; //NEW

	//BONUS
	private ArrayList<String> semanticwords;


    public LuceneIndexerGUI() throws Exception {
        // Create GUI components
        queryLabel = new JLabel("Query:");
        queryField = new JTextField(20);
        titleCheckbox = new JCheckBox("Title");
        artistCheckbox = new JCheckBox("Artist");
        searchButton = new JButton("Search");
        moreButton = new JButton("More"); //moreButton initialization
        resultArea = new JTextArea(10, 40);
        historyArea = new JTextArea();
        historyArea.setEditable(false);
        searchHistory = new ArrayList<String>();
        JScrollPane scrollPane = new JScrollPane(resultArea); //JScrollPane
        JScrollPane historyScrollPane = new JScrollPane(historyArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Set layout
        setLayout(new BorderLayout());
        topPanel = new JPanel(new FlowLayout()); //JPanel
        topPanel.add(scrollPane, BorderLayout.EAST);
        topPanel.add(historyScrollPane, BorderLayout.WEST);
        topPanel.add(queryLabel);
        topPanel.add(queryField);
        topPanel.add(titleCheckbox);
        topPanel.add(artistCheckbox);
        topPanel.add(searchButton);
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);






        try {
            File file = new File("C:\\temp\\indexluc\\search_history.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null && count < 10) {
                sb.append(line).append("\n");
                count++;
            }
            reader.close();
            historyArea.setText(sb.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        // Set up Lucene components
        analyzer = new StandardAnalyzer();
        directory = FSDirectory.open(Paths.get(INDEX_DIRECTORY));
        IndexReader reader = DirectoryReader.open(directory);
        searcher = new IndexSearcher(reader);

        // Add action listener to search button
        searchButton.addActionListener(this);
        resultArea.remove(moreButton);

    }

    public void actionPerformed(ActionEvent e) {
        try {
            String queryText = queryField.getText().trim();
            Query query;
            if (titleCheckbox.isSelected()) {
                QueryParser parser = new QueryParser("song", analyzer);
                query = parser.parse(queryText);
            } else if (artistCheckbox.isSelected()) {
                QueryParser parser = new QueryParser("artist", analyzer);
                query = parser.parse(queryText);
            } else {
                QueryParser parser = new QueryParser("text", analyzer);
                query = parser.parse(queryText);
            }

            TopDocs results = searcher.search(query, 100);
            int totalResults = (int) results.totalHits.value;
            queryString = query.toString(); //queryString initialization
            myquery=query.toString(); //initialization of Myquery(pairnei thn timh tou query Ousiastika)
            searchHistory.add(queryString); // add to query_history.txt

            totalPages = (totalResults/ 10)+1; // Round up
            this.currentResults = results;

            displayResults(currentResults, 0, 10); // Display first 10 results
            currentPage=1;

            // Add "More" button next to "Search" button .
            JPanel topPanel = (JPanel) getContentPane().getComponent(0);
            JPanel buttonPanel = new JPanel();
            searchButton.addActionListener(new ActionListener() { //NEW
                public void actionPerformed(ActionEvent e) {
                	ActionListener[] listeners = moreButton.getActionListeners();
                	if (listeners.length > 0) {
                	    moreButton.removeActionListener(listeners[0]);
                	}

                }
            }); //NEW
            moreButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                    	if(currentPage !=totalPages) { //NEW
                            System.out.print(currentPage); //NEW
                        displayResults(results, (currentPage * 10), 10);
                        currentPage++;
                        return;//NEW
                    	}
                    	else {//NEW
                            System.out.print(currentPage);
                            displayResults(currentResults, (currentPage * 10), 10);
                            currentPage=1;
                        }
                    } catch (Exception ex) {
                        resultArea.setText("Error: " + ex.getMessage());
                    }
                }
            });
            buttonPanel.add(moreButton);
            if (!topPanel.isAncestorOf(moreButton)) {
                topPanel.add(Box.createHorizontalStrut(10));
                topPanel.add(moreButton);
            }
            moreButton.setVisible(true);
            topPanel.add(buttonPanel);
            if(firstsearch==0)//ADDED!
            {
            	pack(); // Resize the frame to fit the new button.Only once not every time.
            	firstsearch++;
            }
            topPanel.add(moreButton, BorderLayout.LINE_END);

            // Update search history
            SearchHistoryItem item = new SearchHistoryItem();

            searchHistory.add(queryString);

            SearchHistoryItem.addToHistory(queryString);//ADDED!

            //Adds the search query to a list of previous search queries.

        } catch (Exception ex) {
            resultArea.setText("Error: " + ex.getMessage());
        }
    }


    private void displayResults(TopDocs results, int start, int count) throws Exception {
    	//start:arxikh 8esh, count:posa apotelesmata 8a typwsei
        resultArea.setText("");
        resultArea.removeAll(); // Remove all components from resultArea .NEW
        if (start == 0) {
            more_counter_display = 0;
        } //NEW
        int totalResults = (int) results.totalHits.value; //posa apotelesmata tairiazoun (#hits)
        int totalPages = (totalResults/count)+1;
        // Reset start to 0 if it exceeds the total number of pages
        if (start >= totalPages * count) {
            start = 0;
            more_counter_display = 0;
        }
        //NEW
        int end = Math.min(start + count, totalResults);

        // Create a map to group the results by artist
        Map<String, List<String>> resultsByArtist = new HashMap<>(); //key:Artist, value:Text and Song of that artist

        for (int i = start; i < end && i < results.scoreDocs.length; i++) {
        	//for sta results apo thn arxh mexri to telos kai pairnei ton artist,song kai text gia ka8e apotelesma to vazei sto sto resultsByArtist
            ScoreDoc scoreDoc = results.scoreDocs[i];
            Document doc = searcher.doc(scoreDoc.doc);
            String artist = doc.get("artist");//pairnei to sygkekrimeno pedio ARTIST apo thn grammh tou .csv arxeiou
            String song = doc.get("song");//pairnei to sygkekrimeno pedio SONG apo thn grammh tou .csv arxeiou
            String text = doc.get("text");//pairnei to sygkekrimeno pedio TEXT apo thn grammh tou .csv arxeiou

            textComponent=new JTextArea(song); //keimeno pou 8elw na kanw highlighter-->song

            // Check if we already have results for this artist
            if (resultsByArtist.containsKey(artist))
            {
            	resultsByArtist.get(artist).add("Song: " + song + "\nText: " + text + "\n\n");

            } else {
            	List<String> songs = new ArrayList<>();//prwta ftiaxnetai to arrayList
                songs.add("Song: " + song + "\nText: " + text + "\n\n"); // add
                resultsByArtist.put(artist, songs);//gia timh gia ton sygkekrimeno kallitexnh . artist:<Song:" ",Text:" ",...>
            }
        }
        // Display the results grouped by artist
        for (Map.Entry<String, List<String>> entry : resultsByArtist.entrySet()) {//for for the MAP (String,<List>)
            String artist = entry.getKey();
            List<String> songs = entry.getValue();

            resultArea.append("Artist: " + artist + "\n");
            for (String song : songs) { //for gia thn lista pou einai ousiastika to value tou sygkekrimenou key.
                resultArea.append(song);
            }
        }
        highlightResults(resultArea,textComponent);

     // Display the current page number
        int currentPage = start / count + 1;
        resultArea.append("Page " + currentPage + " of " + totalPages + "\n");
        if (end < totalResults) {
        	final int finalStart=start; //new
            JButton moreButton = new JButton("More"); //create a new Button "More"
            moreButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                    	System.out.print(end);
                        System.out.print("\n");
                    	int currentStart = finalStart; // Calculate the new start index
                        displayResults(results,currentStart, count); // Update start index. Kanei anadromh
                    } catch (Exception ex) {
                        resultArea.setText("Error: " + ex.getMessage());
                    }
                }
            });
            resultArea.add(moreButton);
        }
        if(more_counter_display==0) //ADDED!
        {
            ArrayList<String> recommendations = new ArrayList<>(SearchHistoryItem.getRecommendations());
            File file = new File("C:\\temp\\indexluc\\search_history.txt");
            if (file.exists()) {
                  BufferedReader reader = new BufferedReader(new FileReader(file));
                  String line;
                  while ((line = reader.readLine()) != null) {
                      if (!line.equals(queryString)) { // Exclude current query from recommendations
                            recommendations.add(line);
                       }
                    }
                    reader.close();
                }
            more_counter_display++;//ADDED!
        }
        highlightResults(resultArea,textComponent);
        //BONUS
        resultArea.append("SEMANTIC RESULTS SEARCH" + "\n");
        openFile();//for semantic
        Analyzer myanalyzer = new StandardAnalyzer();
        Directory mydirectory = FSDirectory.open(Paths.get(INDEX_DIRECTORY));
        IndexReader myreader = DirectoryReader.open(mydirectory);
        IndexSearcher mysearcher = new IndexSearcher(myreader);
        QueryParser parser1 = new QueryParser("song", analyzer);
        Query query1;
        for(int i=0;i<semanticwords.size();i++)
        {
        	query1 = parser1.parse(semanticwords.get(i));
        	TopDocs results1 = mysearcher.search(query1,10);// 3 tragoudia
        	for (int j=0;j< results1.scoreDocs.length; j++) {//ARTIST
            	//for sta results apo thn arxh mexri to telos kai pairnei ton artist,song kai text gia ka8e apotelesma to vazei sto sto resultsByArtist
                ScoreDoc scoreDoc = results1.scoreDocs[j];
                Document doc = mysearcher.doc(scoreDoc.doc);
                String song = doc.get("song");//pairn
                resultArea.append("Song:" +" " +song + "\n");
        	}
        }

    }

    private void highlightResults(JTextArea resultArea,JTextComponent textComponent)
    {
    	//highlighters settings
    	Highlighter hilit=new DefaultHighlighter(); //highlighter
        Highlighter.HighlightPainter painter= new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW); //xrwma
        resultArea.setHighlighter(hilit);//assign the highlighter to the resultArea

        if(myquery.contains("song:"))//an einai tragoudi
        {
        	myquery=myquery.replace("song:"," ");//vgazw to song: apo to query
        }
        else if(myquery.contains("artist:"))//an einai kallitexnhs
        {
        	myquery=myquery.replace("artist:"," ");//vgazw to artist: apo to query
        }
        else //an to query einai stixos
        {
        	myquery=myquery.replace("text:"," ");//vgazw to text apo to query
        }
        try {
        	int song_index=0;
            String text=resultArea.getText();
            //System.out.println(text);
            while((song_index = text.indexOf(myquery,song_index))>= 0)
            {
            	hilit.addHighlight(song_index, song_index + myquery.length(), painter);
                song_index += myquery.length();
            }
        }
        catch (BadLocationException e) {
            e.printStackTrace();
        }
        try {//case if the word is :Nirvana
        	int song_index=0;
            String text=resultArea.getText();
            //System.out.println(text);
            StringBuilder sb = new StringBuilder(myquery);
            sb.setCharAt(1, Character.toUpperCase(myquery.charAt(1)));
            String myquery1=sb.toString();
            while((song_index = text.indexOf(myquery1,song_index))>= 0)
            {
            	hilit.addHighlight(song_index, song_index + myquery1.length(), painter);
                song_index += myquery1.length();
            }
        }
        catch (BadLocationException e) {
            e.printStackTrace();
        }

    }

    //BONUS QUESTION--methods
    public void openFile()
    {
    	ArrayList<Double> queryVector=new ArrayList<>(); //the vector for the query
    	Map<String, ArrayList<Double>>wordMap = new HashMap<>();//word:vector
    	String fileName="C:\\Users\\panad\\Desktop\\AnakthshFinal\\glove.6B\\glove.6B.50d.txt";//open the txt file with the vectors
    	try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String [] elements=line.split(" ");//all elements
                String key;
                key=elements[0]; //the "word"
                String myquery1=myquery;
                myquery1=myquery1.trim();
                if(key.equals(myquery1))
                {
                	for(int i=1;i<elements.length;i++)
                    {
                    	queryVector.add(Double.parseDouble(elements[i])); //convert the "0.3" to 0.3.
                    }
                }
                else
                {
                	ArrayList<Double> vector=new ArrayList<>();
                    for(int i=1;i<elements.length;i++)
                    {
                    	vector.add(Double.parseDouble(elements[i])); //convert the "0.3" to 0.3.
                    }
                    wordMap.put(key,vector);
                }
            }
          Map<String,Double> cosineSimResults=new HashMap<>();//contains the similarity between the query and
          for(String key:wordMap.keySet())
          {
        	  double similarity=cosineSimilarity(queryVector,wordMap.get(key));
        	  cosineSimResults.put(key,similarity);
          }
          List<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String,Double>>(cosineSimResults.entrySet());
          Collections.sort(list, new Comparator<Map.Entry<String,Double>>() {
              public int compare(Map.Entry<String, Double> o1, Map.Entry<String,Double> o2) {
                  return o1.getValue().compareTo(o2.getValue());
              }
          });
          int counter=0;
          Collections.reverse(list);
          semanticwords=new ArrayList<>();
          for(Map.Entry<String, Double> entry : list)
          {
        	  if(counter==10)
        	  {
        		  break;
        	  }
        	  semanticwords.add(entry.getKey());
        	  counter++;
          }
          //for(int i=0;i<semanticwords.size();i++)
          //{
        //	  System.out.println(semanticwords.get(i));
          //}
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public double cosineSimilarity(ArrayList<Double> vectorA, ArrayList<Double> vectorB) {

        double dot=0;
        double normA=0;
        double normB=0;
        for(int i=0;i<vectorA.size();i++)
        {
        	dot+=Math.abs(vectorA.get(i))*Math.abs(vectorB.get(i));
        	normA += vectorA.get(i) * vectorA.get(i);
            normB += vectorB.get(i) * vectorB.get(i);
        }
        //System.out.println(dot);
        double similarity = dot / (Math.sqrt(normA) * Math.sqrt(normB));
        return similarity;
    }

    public static void main(String[] args) {
        try {
            LuceneIndexerGUI gui = new LuceneIndexerGUI();
            gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            gui.setTitle("Lucene Indexer GUI");
            gui.pack();
            gui.setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
